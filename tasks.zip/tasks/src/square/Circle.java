package square;

import java.util.Scanner;

public class Circle extends Shape{

    @Override
    protected double circleArea(double radius){
        double area;
        area = Math.PI * radius * radius;
        return area;
    }

}
