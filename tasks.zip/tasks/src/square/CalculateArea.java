package square;

import java.util.Scanner;

public class CalculateArea {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Circle circle = new Circle();
        Triangle triangle = new Triangle();
        Rectangle rectangle = new Rectangle();
        Input input = new Input();

        System.out.println("Введите название фигуры: ");
        String shape = scanner.nextLine();

        switch (shape) {
            case "круг":
                System.out.println("Введите данные: ");
                double inputData1 = scanner.nextDouble();
                System.out.println("Площадь фигуры равна: ");
                System.out.print(circle.circleArea(inputData1));
                break;
            case "треугольник":
                System.out.println("Введите данные: ");
                inputData1 = scanner.nextDouble();
                double inputData2 = scanner.nextDouble();
                System.out.println("Площадь фигуры равна: ");
                System.out.print(triangle.area(inputData1, inputData2));
                break;
            case "прямоугольник":
                System.out.println("Введите данные: ");
                inputData1 = scanner.nextDouble();
                inputData2 = scanner.nextDouble();
                System.out.println("Площадь фигуры равна: ");
                System.out.print(rectangle.area(inputData1, inputData2));
                break;
            default:
                System.out.println("Извините, данной фигуры нет в нашей базе!");
                break;
        }


    }
}
