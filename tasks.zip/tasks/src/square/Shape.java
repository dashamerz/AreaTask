package square;

public abstract class Shape {

    protected double area(double x, double y) {

        return 0;
    }

    protected double circleArea(double a){
        return 0;
    }

}
