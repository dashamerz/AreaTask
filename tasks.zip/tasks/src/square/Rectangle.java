package square;

import java.util.Scanner;

public class Rectangle extends Shape{

    @Override
    protected double area(double width, double height){
        double area;
        area = width * height;
        return area;
    }


}
