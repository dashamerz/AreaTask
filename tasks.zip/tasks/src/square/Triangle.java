package square;

import java.util.Scanner;

public class Triangle extends Shape{

    @Override
    protected double area(double height, double base) {
        double area;
        area = (height * base) / 2;
        return area;
    }
}