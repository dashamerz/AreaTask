package square;

import java.util.Scanner;

public class Input {


}
